# Палитра приятных цветов (RGB). Один случайный цвет на весь комплект игрока.
data modify storage vibeclub:kit palette set value [14431557, 16747586, 16766287, 9028164, 4885130, 5814743, 6599652, 10057435, 15696047, 13467442, 3361851, 16760012, 11599871, 8442842, 15132390, 7559459]
execute store result storage vibeclub:kit i int 1 run random value 0..15
function vibeclub:kit/pick with storage vibeclub:kit
