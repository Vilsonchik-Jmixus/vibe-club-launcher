$data modify storage vibeclub:kit c set from storage vibeclub:kit palette[$(i)]
function vibeclub:kit/equip with storage vibeclub:kit
