# Нагрудник заменён на медную щупальцевую установку (Create: Octo Arms) с полным воздухом.
# Надеваем только в пустые слоты; если слот занят (старый мир) — кладём в инвентарь.
$execute unless items entity @s armor.head * run item replace entity @s armor.head with minecraft:leather_helmet[minecraft:dyed_color={rgb:$(c)}]
$execute if items entity @s armor.head * unless items entity @s armor.head minecraft:leather_helmet run give @s minecraft:leather_helmet[minecraft:dyed_color={rgb:$(c)}]
execute unless items entity @s armor.chest * run item replace entity @s armor.chest with tentaworks:copper_tentacle_rig[create:banktank_air=900]
execute if items entity @s armor.chest * unless items entity @s armor.chest tentaworks:copper_tentacle_rig run give @s tentaworks:copper_tentacle_rig[create:banktank_air=900]
$execute unless items entity @s armor.legs * run item replace entity @s armor.legs with minecraft:leather_leggings[minecraft:dyed_color={rgb:$(c)}]
$execute if items entity @s armor.legs * unless items entity @s armor.legs minecraft:leather_leggings run give @s minecraft:leather_leggings[minecraft:dyed_color={rgb:$(c)}]
$execute unless items entity @s armor.feet * run item replace entity @s armor.feet with minecraft:leather_boots[minecraft:dyed_color={rgb:$(c)}]
$execute if items entity @s armor.feet * unless items entity @s armor.feet minecraft:leather_boots run give @s minecraft:leather_boots[minecraft:dyed_color={rgb:$(c)}]
