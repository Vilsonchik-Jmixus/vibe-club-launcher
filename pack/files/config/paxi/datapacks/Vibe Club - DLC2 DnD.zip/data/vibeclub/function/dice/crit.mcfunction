tellraw @a[distance=..32] {"text":"✦ КРИТИЧЕСКИЙ УСПЕХ! Боги улыбаются тебе. ✦","color":"gold","bold":true}
playsound minecraft:ui.toast.challenge_complete player @a[distance=..32] ~ ~ ~ 0.7 1.2
particle minecraft:totem_of_undying ~ ~1 ~ 0.4 0.6 0.4 0.3 40
