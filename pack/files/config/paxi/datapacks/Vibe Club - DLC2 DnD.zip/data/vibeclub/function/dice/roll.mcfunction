scoreboard players set @s vc_die_cd 20
$execute store result score @s vc_roll run random value 1..$(sides)
$scoreboard players set #sides vc_roll $(sides)
playsound minecraft:block.bone_block.hit player @a[distance=..16] ~ ~ ~ 1 1.6
playsound minecraft:block.bamboo_wood.hit player @a[distance=..16] ~ ~ ~ 0.8 1.2
$tellraw @a[distance=..32] ["",{"text":"⚅ ","color":"gold"},{"selector":"@s","color":"yellow"},{"text":" бросает ","color":"gray"},{"text":"$(name)","color":"aqua"},{"text":" → ","color":"gray"},{"score":{"name":"@s","objective":"vc_roll"},"color":"white","bold":true}]
execute if score #sides vc_roll matches 20 if score @s vc_roll matches 20 run function vibeclub:dice/crit
execute if score #sides vc_roll matches 20 if score @s vc_roll matches 1 run function vibeclub:dice/fumble
