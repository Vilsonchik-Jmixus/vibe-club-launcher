tellraw @a[distance=..32] {"text":"✖ КРИТИЧЕСКИЙ ПРОВАЛ! Мастер подземелий потирает руки... ✖","color":"dark_red","bold":true}
playsound minecraft:entity.villager.no player @a[distance=..32] ~ ~ ~ 1 0.6
particle minecraft:smoke ~ ~1 ~ 0.3 0.5 0.3 0.02 30
