execute if entity @s[tag=vc_gift_dlc2] run return run tellraw @s {"text":"Ты уже получил подарок DLC 2. Сфера Судьбы выдаётся один раз.","color":"gray"}
tag @s add vc_gift_dlc2
function vibeclub:gift/dlc2_orb
function vibeclub:gift/dlc2_book
function vibeclub:gift/dlc2_dice
tellraw @s ["",{"text":"\n⚔ DLC 2: Классы и Расы ⚔\n","color":"gold","bold":true},{"text":"Ты получил ","color":"yellow"},{"text":"Сферу Судьбы","color":"gold","bold":true},{"text":", Книгу игрока и набор костей.\nПКМ по сфере — выбери расу и класс!\n","color":"yellow"}]
title @s subtitle {"text":"Выбери расу и класс","color":"yellow"}
title @s title {"text":"Сфера Судьбы","color":"gold","bold":true}
playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1
particle minecraft:enchant ~ ~1 ~ 0.5 1 0.5 1 120
