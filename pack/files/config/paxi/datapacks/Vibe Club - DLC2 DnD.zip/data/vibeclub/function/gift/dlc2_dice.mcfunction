function vibeclub:dice/give/d4
function vibeclub:dice/give/d6
function vibeclub:dice/give/d8
function vibeclub:dice/give/d10
function vibeclub:dice/give/d12
function vibeclub:dice/give/d20
function vibeclub:dice/give/d100
give @s fatedice:d20_dice 1
