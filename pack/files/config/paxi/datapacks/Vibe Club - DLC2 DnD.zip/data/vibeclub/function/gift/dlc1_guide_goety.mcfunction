give @s patchouli:guide_book[patchouli:book="goety:black_book"] 1
