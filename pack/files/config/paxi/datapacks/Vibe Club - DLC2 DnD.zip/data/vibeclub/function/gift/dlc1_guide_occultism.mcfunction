give @s occultism:dictionary_of_spirits 1
