give @s ars_nouveau:worn_notebook 1
