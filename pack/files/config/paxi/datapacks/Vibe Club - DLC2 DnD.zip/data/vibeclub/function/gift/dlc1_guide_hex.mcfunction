give @s patchouli:guide_book[patchouli:book="hexcasting:thehexbook"] 1
