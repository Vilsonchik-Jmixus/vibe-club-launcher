execute if entity @s[tag=vc_gift_dlc1] run return run tellraw @s {"text":"Ты уже получил подарок DLC 1. Набор юного мага выдаётся один раз.","color":"gray"}
tag @s add vc_gift_dlc1
function vibeclub:gift/dlc1_guide_ars
function vibeclub:gift/dlc1_guide_occultism
function vibeclub:gift/dlc1_guide_theurgy
function vibeclub:gift/dlc1_guide_hex
function vibeclub:gift/dlc1_guide_goety
function vibeclub:gift/dlc1_resources
tellraw @s ["",{"text":"\n✦ DLC 1: Магия ✦\n","color":"light_purple","bold":true},{"text":"Ты получил Набор юного мага: ","color":"yellow"},{"text":"учебники Ars Nouveau, Occultism, Theurgy, Hex Casting и Goety","color":"aqua"},{"text":" и сырьё для первых крафтов.\n","color":"yellow"},{"text":"Открой книгу квестов → группа «Магия», там пошаговое обучение.\n","color":"gray"}]
title @s subtitle {"text":"Набор юного мага","color":"yellow"}
title @s title {"text":"✦ Магия ✦","color":"light_purple","bold":true}
playsound minecraft:block.enchantment_table.use player @s ~ ~ ~ 1 1
particle minecraft:enchant ~ ~1 ~ 0.5 1 0.5 1 120
