scoreboard objectives add vc_die_use minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add vc_roll dummy
scoreboard objectives add vc_die_cd dummy
