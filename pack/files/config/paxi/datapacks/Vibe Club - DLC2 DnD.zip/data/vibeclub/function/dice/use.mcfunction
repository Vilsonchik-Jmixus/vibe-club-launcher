scoreboard players set @s vc_die_use 0
execute if score @s vc_die_cd matches 1.. run return 0
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{vc_die:4}] run return run function vibeclub:dice/roll {sides:4,name:"d4"}
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{vc_die:6}] run return run function vibeclub:dice/roll {sides:6,name:"d6"}
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{vc_die:8}] run return run function vibeclub:dice/roll {sides:8,name:"d8"}
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{vc_die:10}] run return run function vibeclub:dice/roll {sides:10,name:"d10"}
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{vc_die:12}] run return run function vibeclub:dice/roll {sides:12,name:"d12"}
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{vc_die:20}] run return run function vibeclub:dice/roll {sides:20,name:"d20"}
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{vc_die:100}] run return run function vibeclub:dice/roll {sides:100,name:"d100"}
