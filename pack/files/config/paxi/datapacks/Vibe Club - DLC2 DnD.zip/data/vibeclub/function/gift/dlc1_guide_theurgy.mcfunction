give @s modonomicon:modonomicon[modonomicon:book_id="theurgy:the_hermetica"] 1
