execute as @a[scores={vc_die_use=1..}] at @s run function vibeclub:dice/use
scoreboard players remove @a[scores={vc_die_cd=1..}] vc_die_cd 1
