tag @s remove vc_gift_dlc3
