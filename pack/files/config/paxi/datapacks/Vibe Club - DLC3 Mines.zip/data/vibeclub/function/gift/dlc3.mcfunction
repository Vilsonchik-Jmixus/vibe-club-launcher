execute if entity @s[tag=vc_gift_dlc3] run return run tellraw @s {"text":"Ты уже получил подарок DLC 3. Кирка Шахтёра выдаётся один раз.","color":"gray"}
tag @s add vc_gift_dlc3
give @s minecraft:diamond_pickaxe[custom_name='{"text":"Кирка Шахтёра","color":"aqua","italic":false}',lore=['{"text":"Подарок DLC 3 «Мир шахтёра»","color":"gray","italic":false}','{"text":"/mine — в мир шахт и обратно","color":"dark_aqua","italic":false}']] 1
tellraw @s ["",{"text":"\n⛏ DLC 3: Мир шахтёра ⛏\n","color":"gold","bold":true},{"text":"Ты получил ","color":"yellow"},{"text":"Кирку Шахтёра","color":"aqua","bold":true},{"text":".\nКоманда ","color":"yellow"},{"text":"/mine","color":"gold","bold":true},{"text":" перенесёт тебя в мир бесконечных шахт, повторная — обратно.\n","color":"yellow"}]
title @s subtitle {"text":"/mine — в мир шахт","color":"yellow"}
title @s title {"text":"Кирка Шахтёра","color":"aqua","bold":true}
playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1
particle minecraft:wax_off ~ ~1 ~ 0.5 1 0.5 1 60
