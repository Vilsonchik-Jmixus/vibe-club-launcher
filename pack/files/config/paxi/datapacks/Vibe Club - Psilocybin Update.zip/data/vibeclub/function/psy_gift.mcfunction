give @s psychadelic:magic_mushroomspores 2
give @s psychadelic:rubber_tree_sapling 1
tellraw @s ["",{"text":"[Vibe Club] ","color":"light_purple"},{"text":"Псилоцибин апдейт! ","color":"gold"},{"text":"Держи подарок: споры волшебных грибов и саженец каучукового дерева. Рецепты для редких растений и минералов — в JEI.","color":"white"}]
