execute if entity @s[tag=vc_gift_dlc4] run return run tellraw @s {"text":"Ты уже получил подарок DLC 4.","color":"gray"}
tag @s add vc_gift_dlc4
give @s thaumaturge:thaumonomicon 1
give @s thaumaturge:thaumometer 1
give @s thaumaturge:scribing_tools 1
give @s thaumaturge:salis_mundus 2
give @s astralsorcery:tome 1
give @s astralsorcery:wand 1
give @s astralsorcery:glass_lens 2
tellraw @s {"text":"Ты получил набор DLC 4. Открой Таумономикон и Астральный том, а затем найди обе ветки в разделе «Магия».","color":"gold"}
